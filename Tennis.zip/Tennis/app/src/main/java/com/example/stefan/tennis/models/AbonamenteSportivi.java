package com.example.stefan.tennis.models;

import com.example.stefan.tennis.database.TenisDatabase;
import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.ForeignKey;
import com.raizlabs.android.dbflow.annotation.OneToMany;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.sql.language.SQLite;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.util.Date;
import java.util.List;

@Table(name = "abonamente_sportivi", database = TenisDatabase.class)
public class AbonamenteSportivi extends BaseModel{
    @PrimaryKey(autoincrement = true)
    private int id;
    @ForeignKey
    private Sportiv sportiv;
    @ForeignKey
    private Abonament abonament;
    @Column(name = "date_sedinte")
    private Date dataSedinta;

    List<IstoricAntrenamente> istoricAntrenamenteList;

    public AbonamenteSportivi(){

    }

    public AbonamenteSportivi(int id, Sportiv sportiv, Abonament abonament, Date dataSedinte) {
        this.id = id;
        this.sportiv = sportiv;
        this.abonament = abonament;
        this.dataSedinta = dataSedinte;
    }

    @OneToMany(methods = {OneToMany.Method.ALL}, variableName = "istoricAntrenamenteList")
    public List<IstoricAntrenamente> getIstoricAntrenamente() {
        if (istoricAntrenamenteList == null || istoricAntrenamenteList.isEmpty()) {
            istoricAntrenamenteList = SQLite.select()
                    .from(IstoricAntrenamente.class)
                    .where(IstoricAntrenamente_Table.abonamanteSportiv_id.eq(id))
                    .queryList();
        }
        return istoricAntrenamenteList;
    }

    public int getId() {
        return id;
    }

    public Sportiv getSportiv() {
        return sportiv;
    }

    public Abonament getAbonament() {
        return abonament;
    }

    public Date getDataSedinta() {
        return dataSedinta;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setSportiv(Sportiv sportiv) {
        this.sportiv = sportiv;
    }

    public void setAbonament(Abonament abonament) {
        this.abonament = abonament;
    }

    public void setDataSedinta(Date dataSedinta) {
        this.dataSedinta = dataSedinta;
    }
}
