package com.example.stefan.tennis.models;

import com.example.stefan.tennis.database.TenisDatabase;
import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.OneToMany;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.sql.language.SQLite;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.util.List;

@Table(name = "antrenori", database = TenisDatabase.class)
public class Antrenor extends BaseModel{

    @PrimaryKey(autoincrement = true)
    private int id;
    @Column
    private String nume;
    @Column
    private String prenume;
    @Column
    private String email;
    @Column
    private String parola;

    List<IstoricAntrenamente> istoricAntrenamenteList;

    public Antrenor(){

    }

    public Antrenor(int id, String nume, String prenume, String email, String parola) {
        this.id = id;
        this.nume = nume;
        this.prenume = prenume;
        this.email = email;
        this.parola = parola;
    }

    @OneToMany(methods = {OneToMany.Method.ALL}, variableName = "istoricAntrenamenteList")
    public List<IstoricAntrenamente> getIstoricAntrenamente() {
        if (istoricAntrenamenteList == null || istoricAntrenamenteList.isEmpty()) {
            istoricAntrenamenteList = SQLite.select()
                    .from(IstoricAntrenamente.class)
                    .where(IstoricAntrenamente_Table.antrenor_id.eq(id))
                    .queryList();
        }
        return istoricAntrenamenteList;
    }

    public int getId() {
        return id;
    }

    public String getNume() {
        return nume;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPrenume() {
        return prenume;
    }

    public String getEmail() {
        return email;
    }

    public String getParola() {
        return parola;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }
}
