package com.example.stefan.tennis.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.stefan.tennis.R;

public class Register extends AppCompatActivity {

    private EditText name;
    private EditText surmane;
    private EditText date;
    private final String TAG=Register.this.getClass().getSimpleName();
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        name = (EditText) findViewById(R.id.nameTxt);
        surmane = (EditText) findViewById(R.id.surnameTxt);
        date = (EditText) findViewById(R.id.dateTxt);
        btn = (Button) findViewById(R.id.btnStart);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String prenume = name.getText().toString();
                String nume = surmane.getText().toString();
                String data = date.getText().toString();

                Intent next = new Intent(Register.this, MainActivity.class);
                startActivity(next);
            }
        });
    }
}
