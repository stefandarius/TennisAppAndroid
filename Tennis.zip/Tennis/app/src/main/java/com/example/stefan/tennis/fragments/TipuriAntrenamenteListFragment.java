package com.example.stefan.tennis.fragments;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SearchView;

import com.example.stefan.tennis.R;
import com.example.stefan.tennis.adapters.TipAntrenamentAdapter;
import com.example.stefan.tennis.models.TipAntrenament;

import java.util.List;

public class TipuriAntrenamenteListFragment extends Fragment implements AddTipAntrenamentFragment.OnAntrenamentSaved{

    private ListView listaAntrenamente;
    private TipAntrenamentAdapter tipAntrenamentAdapter;
    private SearchView searchView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_tip_antrenament_list, container, false);
        initFragmentUI(view);
        return view;
    }

    private void initFragmentUI(View view) {
        List<TipAntrenament> antrenamente = TipAntrenament.getAll();
        tipAntrenamentAdapter = new TipAntrenamentAdapter(getActivity(), antrenamente);
        listaAntrenamente = view.findViewById(R.id.listView);
        searchView=view.findViewById(R.id.searchView);
        FloatingActionButton fab = getActivity().findViewById(R.id.fab);
        fab.setVisibility(View.VISIBLE);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                AddTipAntrenamentFragment addTipAntrenamentFragment = new AddTipAntrenamentFragment();
                addTipAntrenamentFragment.setOnAntrenamentSaved(TipuriAntrenamenteListFragment.this);
                fragmentTransaction.add(R.id.main_container, addTipAntrenamentFragment, "ADD_TIP_ANTRENAMENT_FRAGMENT")
                        .addToBackStack(null)
                        .commit();
            }
        });
        listaAntrenamente.setAdapter(tipAntrenamentAdapter);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
               tipAntrenamentAdapter.getFilter().filter(newText);
                return true;
            }
        });
    }

    @Override
    public void onAntrenamentSaved(TipAntrenament ta) {
        tipAntrenamentAdapter.add(ta);
        tipAntrenamentAdapter.notifyDataSetChanged();
    }
}
