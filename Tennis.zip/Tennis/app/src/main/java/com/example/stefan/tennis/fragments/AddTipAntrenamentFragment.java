package com.example.stefan.tennis.fragments;


import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.stefan.tennis.R;
import com.example.stefan.tennis.models.TipAntrenament;

public class AddTipAntrenamentFragment extends Fragment {
    private EditText etxtDenumire;
    private CheckBox ckbStatus;
    private Button btnSave;
    private OnAntrenamentSaved onAntrenamentSaved;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tip_antrenament, container, false);
        initFragmentUI(view);
        return view;
    }

    private void initFragmentUI(View view) {
        etxtDenumire = view.findViewById(R.id.etxtDenumire);
        ckbStatus = view.findViewById(R.id.ckbStatus);
        ckbStatus.setChecked(true);
        btnSave = view.findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TipAntrenament tp = new TipAntrenament();
                tp.setDenumirea(etxtDenumire.getText().toString().trim());
                tp.setActiv(ckbStatus.isChecked());
                try {
                    if (tp.save()) {
                        Toast.makeText(getActivity(), "Tip antrenament adaugat", Toast.LENGTH_SHORT).show();
                        onAntrenamentSaved.onAntrenamentSaved(tp);
                        getActivity().onBackPressed();
                    } else {
                        Toast.makeText(getActivity(), "Eroare", Toast.LENGTH_SHORT).show();
                    }

                } catch (SQLiteConstraintException ex) {
                    if (ex.getMessage().contains("denumire")) {
                        etxtDenumire.selectAll();
                        etxtDenumire.requestFocus();
                        Toast.makeText(getActivity(), "Acest antrenament exista deja", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

    public void setOnAntrenamentSaved(OnAntrenamentSaved onAntrenamentSaved) {
        this.onAntrenamentSaved = onAntrenamentSaved;
    }

    public interface OnAntrenamentSaved{
        void onAntrenamentSaved(TipAntrenament ta);
    }

}
