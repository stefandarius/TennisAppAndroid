package com.example.stefan.tennis.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.example.stefan.tennis.R;
import com.example.stefan.tennis.adapters.TipAntrenamentAdapter;
import com.example.stefan.tennis.models.TipAntrenament;

import java.util.List;

public class TipuriAntrenamenteActivity extends AppCompatActivity {

    private ListView listaAntrenamente;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip_antrenament_list);

        List<TipAntrenament> antrenamente = TipAntrenament.getAll();
        TipAntrenamentAdapter tipAntrenamentAdapter = new TipAntrenamentAdapter(this, antrenamente);

        listaAntrenamente = findViewById(R.id.listView);
        listaAntrenamente.setAdapter(tipAntrenamentAdapter);
    }
}
