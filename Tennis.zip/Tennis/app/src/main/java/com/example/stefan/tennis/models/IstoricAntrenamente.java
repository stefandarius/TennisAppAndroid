package com.example.stefan.tennis.models;

import com.example.stefan.tennis.database.TenisDatabase;
import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.ForeignKey;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.util.Date;

@Table(name = "istoric_antrenamente", database = TenisDatabase.class)
public class IstoricAntrenamente extends BaseModel{

    public final static int USOR = 1;
    public final static int MEDIU = 2;
    public final static int GREU = 3;


    @PrimaryKey(autoincrement = true)
    private int id;
    @ForeignKey(saveForeignKeyModel = false)
    private Antrenor antrenor;
    @ForeignKey(saveForeignKeyModel = false)
    private AbonamenteSportivi abonamanteSportiv;
    @ForeignKey(saveForeignKeyModel = false)
    private TipAntrenament tipAntrenament;
    @Column(name = "grad_dificultate")
    private int gradDificultate;
    @Column
    private int rating;
    @Column(name = "data_antrenament")
    private Date dataAntrenament;

    public IstoricAntrenamente(){

    }

    public IstoricAntrenamente(int id, Antrenor antrenor, AbonamenteSportivi sportiv, TipAntrenament tipAntrenament, int gradDificultate, int rating, Date dataAntrenament) {
        this.id = id;
        this.antrenor = antrenor;
        this.abonamanteSportiv = sportiv;
        this.tipAntrenament = tipAntrenament;
        this.gradDificultate = gradDificultate;
        this.rating = rating;
        this.dataAntrenament = dataAntrenament;
    }

    public int getId() {
        return id;
    }

    public Antrenor getAntrenor() {
        return antrenor;
    }

    public Sportiv getSportiv() {
        return abonamanteSportiv.getSportiv();
    }

    public Abonament getAbonament() { return abonamanteSportiv.getAbonament();}

    public TipAntrenament getTipAntrenament() {
        return tipAntrenament;
    }

    public int getGradDificultate() {
        return gradDificultate;
    }

    public int getRating() {
        return rating;
    }

    public Date getDataAntrenament() {
        return dataAntrenament;
    }

    public AbonamenteSportivi getAbonamanteSportiv() { return abonamanteSportiv; }

    public void setId(int id) {
        this.id = id;
    }

    public void setAntrenor(Antrenor antrenor) {
        this.antrenor = antrenor;
    }

    public void setSportiv(AbonamenteSportivi abonamanteSportiv) {
        this.abonamanteSportiv = abonamanteSportiv;
    }

    public void setTipAntrenament(TipAntrenament tipAntrenament) {
        this.tipAntrenament = tipAntrenament;
    }

    public void setGradDificultate(int gradDificultate) {
        this.gradDificultate = gradDificultate;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setDataAntrenament(Date dataAntrenament) {
        this.dataAntrenament = dataAntrenament;
    }

    public void setAbonamanteSportiv(AbonamenteSportivi abonamanteSportiv) { this.abonamanteSportiv = abonamanteSportiv; }
}
