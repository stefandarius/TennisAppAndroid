package com.example.stefan.tennis.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;

import com.example.stefan.tennis.R;
import com.example.stefan.tennis.models.TipAntrenament;

import java.util.ArrayList;
import java.util.List;

public class TipAntrenamentAdapter extends ArrayAdapter<TipAntrenament> {

    private final ArrayList<TipAntrenament> origData;
    private List<TipAntrenament> listaAntrenamente;

    public TipAntrenamentAdapter(@NonNull Context context, @NonNull List<TipAntrenament> objects) {
        super(context, android.R.layout.simple_list_item_1, objects);
        this.listaAntrenamente = objects;
        this.origData = new ArrayList<>(objects);

    }

    @Override
    public Filter getFilter(){
        return new Filter(){

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                constraint = constraint.toString().toLowerCase();
                FilterResults result = new FilterResults();

                if (constraint != null && constraint.toString().length() > 0) {
                    List<TipAntrenament> founded = new ArrayList<TipAntrenament>();
                    for(TipAntrenament item: origData){
                        if(item.getDenumirea().toLowerCase().startsWith(constraint.toString())){
                            founded.add(item);
                        }
                    }

                    result.values = founded;
                    result.count = founded.size();
                }else {
                    result.values = origData;
                    result.count = origData.size();
                }
                return result;


            }
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                clear();
                for (TipAntrenament item : (List<TipAntrenament>) results.values) {
                    add(item);
                }
                notifyDataSetChanged();

            }
        };
    }

    @Override
    public int getCount() {
        return listaAntrenamente.size();
    }

    @Nullable
    @Override
    public TipAntrenament getItem(int position) {
        return listaAntrenamente.get(position);
    }

    @Override
    public long getItemId(int position) {
        return listaAntrenamente.get(position).getId();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolderItem viewHolderItem;
        if(convertView == null){
            LayoutInflater  layoutInflater = ((Activity)getContext()).getLayoutInflater();
            convertView = layoutInflater.inflate(R.layout.row_tip_anatrenament, parent, false);
            viewHolderItem = new ViewHolderItem();
            viewHolderItem.txtDenumire = convertView.findViewById(R.id.txtDenumire);
            viewHolderItem.txtStatus = convertView.findViewById(R.id.txtStatus);
            convertView.setTag(viewHolderItem);
        } else {
            viewHolderItem = (ViewHolderItem)convertView.getTag();
        }
        TipAntrenament ta = listaAntrenamente.get(position);
        viewHolderItem.txtDenumire.setText(ta.getDenumirea());
        viewHolderItem.txtStatus.setText(ta.isActiv()? "Da" : "Nu");
        return convertView;
    }

    static class ViewHolderItem {
        TextView txtDenumire;
        TextView txtStatus;


    }
}
