package com.example.stefan.tennis.models;

import com.example.stefan.tennis.database.TenisDatabase;
import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.ConflictAction;
import com.raizlabs.android.dbflow.annotation.OneToMany;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.annotation.Unique;
import com.raizlabs.android.dbflow.sql.language.SQLite;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.util.List;

@Table(name = "tipuri_antrenamente", database = TenisDatabase.class)
public class TipAntrenament extends BaseModel{

    @PrimaryKey(autoincrement = true)
    private int id;
    @Unique (onUniqueConflict = ConflictAction.FAIL)
    @Column
    private String denumirea;
    @Column
    private boolean activ;

    List<IstoricAntrenamente> istoricAntrenamente;

    public TipAntrenament() {

    }

    public TipAntrenament(int id, String denumirea, boolean activ) {
        this.id = id;
        this.denumirea = denumirea;
        this.activ = activ;
    }

    @OneToMany(methods = {OneToMany.Method.ALL}, variableName = "istoricAntrenamente")
    public List<IstoricAntrenamente> getInregistrariSedinte() {
        if (istoricAntrenamente == null || istoricAntrenamente.isEmpty()) {
            istoricAntrenamente = SQLite.select()
                    .from(IstoricAntrenamente.class)
                    .where(IstoricAntrenamente_Table.tipAntrenament_id.eq(id))
                    .queryList();
        }
        return istoricAntrenamente;
    }

    public int getId() {
        return id;
    }

    public String getDenumirea() {
        return denumirea;
    }

    public boolean isActiv() {
        return activ;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDenumirea(String denumirea) {
        this.denumirea = denumirea;
    }

    public void setActiv(boolean activ) {
        this.activ = activ;
    }

    public static List<TipAntrenament> getAll(){
        return SQLite.select()
                .from(TipAntrenament.class)
                .queryList();
    }
}
