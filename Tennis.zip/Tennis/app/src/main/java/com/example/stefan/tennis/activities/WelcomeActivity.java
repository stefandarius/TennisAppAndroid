package com.example.stefan.tennis.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.stefan.tennis.R;
import com.example.stefan.tennis.models.Abonament;
import com.example.stefan.tennis.models.Sportiv;

import java.util.Date;

public class WelcomeActivity extends AppCompatActivity {

    public Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        btn = (Button) findViewById(R.id.btnRegister);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next = new Intent(WelcomeActivity.this, Register.class);
                startActivity(next);
            }
        });

        Abonament ab = new Abonament();
        ab.setDenumire("Abonament tenis standard");
        ab.setNrSedinte(10);
        ab.setPret(200);
        ab.save();

        Sportiv s = new Sportiv();
        s.setNume("Iordache");
        s.setPrenume("Stefan");
        s.setEmail("afgfgsa");
        s.setGreutate(68);
        s.setInaltime(180);
        s.setSex(true);
        s.setNivel(Sportiv.NIVEL_AVANSAT);
        s.setDataNastere(new Date());
        s.setStareSanatate(Sportiv.STARE_SANATOS);
    }
}
